import sys
import cutter

if __name__ == '__main__':
    c = cutter.Cutter()
    c.cut(sys.listitem)